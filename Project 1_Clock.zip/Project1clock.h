/*
 * Project1clock.h
 *
 *  Created on: Nov 12, 2023
 *      Author: carterwilliam_snhu
 */

#ifndef PROJECT1CLOCK_H_
#define PROJECT1CLOCK_H_

class Project1_clock {
public:
	Project1_clock();
	virtual ~Project1_clock();
};

#endif /* PROJECT1CLOCK_H_ */
