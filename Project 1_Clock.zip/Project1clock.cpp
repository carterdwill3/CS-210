/* Carter Williams
   12 November 2023
   SNHU - CS-210_Project 1
*/

#include <iostream>

using namespace std;

//class and data inserts
class Project1_clock{
	private:
    	int hours24;
    	int minutes;
    	int seconds;
    	int numberOfYears;
    	bool am_pm;

//method to 12-hour clock (am & pm)
    int CalcHour12(bool& am_pm){
    	if (hours24 <= 12){
    		am_pm = 0;
            return hours24;
        }
        else{
        	am_pm = 1;
            return hours24 - 12;   //negates 24-hour clock - subtracts 12 if hours is more than <=13
        }
    }

    void AddHour(void){
    	hours24++;
    	if (hours24 == 23){
    		hours24 = 0;   //resets hours after limit has reached
        }
    }

    void AddMinute(void){
    	minutes++;
    	if (minutes == 59){
    		minutes = 0;
    		AddHour();   //adds hour when max minutes has reached - resets minutes
        }
    }

    void AddSecond(void){
    	seconds++;
        if (seconds == 59){
            seconds = 0;
            AddMinute();   //adds minute when max seconds has reached - resets seconds
        }
    }

    void DisplayTime(void){
    	for (int i = 0; i < 27; i++){
        	cout << "*";   //asterisk insert
        }
        cout << "    ";   //spacing insert
        for (int i = 0; i < 27; i++){
            cout << "*";   //asterisk insert
        }
        cout << endl;   //new line insert

        cout << "*      12-Hour Clock      *    *      24-Hour Clock      *" << endl;   //clock display

        //display for 12-hour clock
        cout << "*       ";
        //hours output
        if (CalcHour12(am_pm) < 10){
            cout << "0" << CalcHour12(am_pm) << ":";
        }
        else{
            cout << CalcHour12(am_pm) << ":";
        }
        //minutes output
        if (minutes < 10){
            cout << "0" << minutes << ":";
        }
        else{
            cout << minutes << ":";
        }
        //seconds output
        if (seconds < 10){
            cout << "0" << seconds << "          *" << endl;
        }
        else{
            cout << seconds;
        }
        //displays am or pm for 12-hour clock
        if (am_pm == 0){
            cout << " AM" << "       *";
        }
        else{
            cout << " PM" << "       *";
        }

        cout << "    ";   //insert spacing

        //display for 24-hour clock
        cout << "*        ";
        //hours output
        if (hours24 < 10){
            cout << "0" << hours24 << ":";
        }
        else{
            cout << hours24 << ":";
        }
        //minutes output
        if (minutes < 10){
            cout << "0" << minutes << ":";
        }
        else{
            cout << minutes << ":";
        }
        //seconds output
        if (seconds < 10){
            cout << "0" << seconds << "          *" << endl;
        }
        else{
            cout << seconds << "         *" << endl;
        }

        for (int i = 0; i < 27; i++){
            cout << "*";   //asterisk insert
        }

        cout << "    ";   //spacing insert

        for (int i = 0; i < 27; i++){
            cout << "*";   //asterisk insert
        }
    }

    void DisplayMenu(void){
        for (int i = 0; i < 27; i++){
            cout << "*";   //asterisk insert
        }

        cout << endl;   //new line

        cout << "* 1 - Add One Hour        *" << endl;   //add hour display - new line insert

        cout << "* 2 - Add One Minute      *" << endl;   //add minute display - new line insert

        cout << "* 3 - Add One Second      *" << endl;   ////add second display - new line insert

        cout << "* 4 - Exit Program        *" << endl;   //leave clock display - new line insert

        for (int i = 0; i < 27; i++){
            cout << "*";   //asterisk insert
        }
    }

//ClearScreen object_name
public:
    void ClearScreen(void){
        system("CLS");
    }

//Display object_name
    void Display(void){
        DisplayTime();
        cout << endl;
        DisplayMenu();
    }

//ReadUserInput object_name
    bool ReadUserInput(void){
        int input;
        cin >> input;

        //case references from options in adding second, minute, hour, or leaving clock
        switch (input){
        	case 1:
        		AddHour();
            	return false;
            	break;
        	case 2:
        		AddMinute();
        		return false;
        		break;
        	case 3:
        		AddSecond();
        		return false;
        		break;
        	case 4:
        		return true;
        		break;
        }
    }

    void Init(int hour, int minute, int second){
        hours24 = hour;
        minutes = minute;
        seconds = second;
    }
};

int main(void){
    Project1_clock Project1; //builds object from class name

    Project1.Init(8, 3, 15); //calculates for object using written path

    //calls out the calculations
    while (1){
        Project1.ClearScreen();
        Project1.Display();
        cout << endl;
        if (Project1.ReadUserInput())
            break;         //end
    }
}
