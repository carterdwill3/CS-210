/*
 * InvestmentCalculatorCarter.cpp
 *  Created on: Jun 09, 2024
 *      Author: carterwilliam_snhu
 */

#include "InvestmentCalculatorCarter.h"
//classes included
#include <iostream>
#include <iomanip>
#include <string>

InvestmentCalculator_Carter::InvestmentCalculator_Carter() {
	// TODO Auto-generated constructor stub

}

InvestmentCalculator_Carter::~InvestmentCalculator_Carter() {
	// TODO Auto-generated destructor stub
}

using namespace std;

// Function to calculate the balance at the end of a year
double calculateYearlyBalance(double balance, double monthlyDeposit, double annualInterestRate) {
    return balance + (monthlyDeposit > 0 ? monthlyDeposit : 0) + (balance * annualInterestRate / 100);
}

//function to display results
void displayResults(double totalDeposits, double totalInterest, double finalBalance) {
    cout << fixed << setprecision(2);
    cout << "Total Deposits: $" << totalDeposits << endl;
    cout << "Total Interest: $" << totalInterest << endl;
    cout << "Final Balance: $" << finalBalance << endl;
}

int main() {
    //initializes variables
    double initialInvestment = 0.0;
    double monthlyDeposit = 0.0;
    double annualInterestRate = 0.0;
    int numYears = 0;
    double totalDeposits = 0.0;
    double totalInterest = 0.0;
    double balance = 0.0;
    double yearlyBalance = 0.0;

    //ask user for input
    cout << "Welcome to Airgead Banking Investing Calculator." << endl;
    cout << "Enter starting investment: ";
    cin >> initialInvestment;
    cout << "Enter monthly deposit (put 0 if none): ";
    cin >> monthlyDeposit;
    cout << "Enter annual interest rate (as percentage): ";
    cin >> annualInterestRate;
    cout << "Enter number of years in investment planning: ";
    cin >> numYears;

    //performs investment calculation
    for (int i = 1; i <= numYears; i++) {
        balance = calculateYearlyBalance(balance, monthlyDeposit, annualInterestRate);
        totalDeposits += monthlyDeposit > 0 ? monthlyDeposit : 0;
        totalInterest += balance - initialInvestment - totalDeposits;
        yearlyBalance = balance;
        cout << "Year " << i << ": $" << fixed << setprecision(2) << yearlyBalance << endl;
    }

    //display results
    displayResults(totalDeposits, totalInterest, yearlyBalance);

    return 0;
}
