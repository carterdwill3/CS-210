/*
 * InvestmentCalculatorCarter.h
 *
 *  Created on: Jun 16, 2024
 *      Author: carterwilliam_snhu
 */

#ifndef INVESTMENTCALCULATORCARTER_H_
#define INVESTMENTCALCULATORCARTER_H_

class InvestmentCalculator_Carter {
public:
	InvestmentCalculator_Carter();
	virtual ~InvestmentCalculator_Carter();
};

#endif /* INVESTMENTCALCULATORCARTER_H_ */
