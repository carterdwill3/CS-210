/*
 * cornerGrocer.h
 *
 *  Created on: Jun 30, 2024
 *      Author: carterwilliam_snhu
 */

#ifndef CORNERGROCER_H_
#define CORNERGROCER_H_

class cornerGrocer {
public:
	cornerGrocer();
	virtual ~cornerGrocer();
};

#endif /* CORNERGROCER_H_ */
