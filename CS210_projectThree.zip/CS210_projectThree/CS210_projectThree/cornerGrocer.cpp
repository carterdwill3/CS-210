/*
 * cornerGrocer.cpp
 *
 *  Created on: Jun 24, 2024
 *      Author: carterwilliam_snhu
 */

#include "cornerGrocer.h"
#include <iostream>
#include <string>
#include <fstream>
#include <vector>

using namespace std;

//function that calls a Python procedure
void callProcedure(string procName) {
    //loads the module
    Py_Initialize();
    PyObject* pName, *pModule, *pDict, *pFunc;
    pName = PyUnicode_FromString("python_script");
    pModule = PyImport_Import(pName);
    pDict = PyModule_GetDict(pModule);
    pFunc = PyDict_GetItemString(pDict, procName.c_str());
    //calls the Python procedure
    PyObject_CallObject(pFunc, NULL);
    //flinalizes the Python interpreter
    Py_Finalize();
}

//function that	calls an integer Python function
int callIntFunc(string procName, string param) {
    //starts the Python interpreter and loads the module
    Py_Initialize();
    PyObject* pName, *pModule, *pDict, *pFunc, *pValue;
    pName = PyUnicode_FromString("python_script");
    pModule = PyImport_Import(pName);
    pDict = PyModule_GetDict(pModule);
    pFunc = PyDict_GetItemString(pDict, procName.c_str());

    //will convert the input into a Python value
    pValue = Py_BuildValue("(z)", param.c_str());

    //will call the Python function with the input parameter
    PyObject* result = PyObject_CallObject(pFunc, pValue);

    //used to convert result to an integer
    int resultInt = _PyLong_AsInt(result);

    Py_DECREF(pValue);
    Py_DECREF(pModule);
    Py_DECREF(pName);
    Py_Finalize();

    return resultInt;
}

//code to shape menu
void drawMenu() {
    int menuLoop;

    while (true) {
        cout << "Select an option:" << endl;
        cout << "1. View item frequency statistics" << endl;
        cout << "2. Search for a specific item's occurrence" << endl;
        cout << "3. Visualize item frequency distribution" << endl;
        cout << "4. Exit program" << endl;
        cin >> menuLoop;

        switch (menuLoop) {
            case 1:
                //calls the Python procedure to count all items
                callProcedure("CountAll");
                break;
            case 2:
            	//calls for items to enter, and checks instances
                string searchTerm;
                cout << "Enter the item to search for: ";
                cin >> searchTerm;
                int wordCount = callIntFunc("CountInstances", searchTerm);
                cout << searchTerm << ": " << wordCount << endl << endl;
                break;
            case 3:
                //calls the Python procedure to collect data and print a histogram
                callProcedure("CollectData");
                ifstream file("frequency.dat");
                string itemName;
                int itemQuantity;
                while (file >> itemName >> itemQuantity) {
                    cout << itemName << ": ";
                    for (int i = 0; i < itemQuantity; i++) {
                        cout << "*";
                    }
                    cout << endl;
                }
                file.close();
                break;
            case 4:
            	//incorrect/missing choice or input method
                return;
            default:
                cout << "Oops, it seems you've encountered an error. Please try again!" << endl;
        }
    }
}
